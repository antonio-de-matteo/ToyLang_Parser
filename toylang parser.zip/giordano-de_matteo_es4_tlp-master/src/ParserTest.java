// Circuit.java


import Expressions.*;
import Expressions.ExprAnd;
import Expressions.ExprDiv;
import Expressions.ExprNull;
import Visitor.Visitor;
import java_cup.runtime.ComplexSymbolFactory;
import java_cup.runtime.Symbol;
import org.w3c.dom.Element;

import javax.xml.transform.Result;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Scanner;

public class ParserTest {
    public static void main(String[] args) throws Exception {
        String filePath = args[0];
        ComplexSymbolFactory sf = new ComplexSymbolFactory();
        Parser parser  = new Parser((new Lexer(new FileReader(filePath),sf)),sf);
        Program s=(Program) parser.parse().value;
         // l'uso di p.debug_parse() al posto di p.parse() produce tutte le azioni del parser durante il riconoscimento
        Visitor v= new Visitor();
        v.appendRoot((Element) v.visit(s));
        v.getXMLtree(filePath);
    }
}
// End of file
