package Expressions;

import Visitor.Visitor;
import java_cup.runtime.ComplexSymbolFactory.Location;


public class Expr {
    private Location dx;
    private Location sx;
    private Object object;

    public Expr(Location sx, Location dx, Object ob)
    {
        this.dx=dx;
        this.sx=sx;
        object=ob;
    }

    public Expr(Location sx, Location dx)
    {
        this.dx=dx;
        this.sx=sx;
        object=null;
    }

    public Expr(Object o)
    {

        object=o;

    }

    public Expr()
    {
        this.dx=null;
        this.sx=null;
        object=null;
    }


    public Location getDx() {
        return dx;
    }

    public void setDx(Location dx) {
        this.dx = dx;
    }

    public Location getSx() {
        return sx;
    }

    public void setSx(Location sx) {
        this.sx = sx;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public Object accept (Visitor v) {
        return v.visit(this);
    }

}
