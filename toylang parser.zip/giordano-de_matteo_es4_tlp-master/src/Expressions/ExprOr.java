package Expressions;

import Visitor.Visitor;
import java_cup.runtime.ComplexSymbolFactory.Location;

public class ExprOr extends Expr {

    private Expr eleft,eright;

    public ExprOr(Location sx, Location dx, Expr eleft, Expr eright) {
        super(sx, dx);
        this.eleft = eleft;
        this.eright = eright;
    }

    public Expr getEleft() {
        return eleft;
    }

    public void setEleft(Expr eleft) {
        this.eleft = eleft;
    }

    public Expr getEright() {
        return eright;
    }

    public void setEright(Expr eright) {
        this.eright = eright;
    }
    public Object accept (Visitor v) {
        return v.visit(this);
    }
}
