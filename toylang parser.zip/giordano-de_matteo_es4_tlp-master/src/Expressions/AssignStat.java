package Expressions;

import Visitor.Visitor;
import java_cup.runtime.ComplexSymbolFactory.Location;

public class AssignStat {

    private Location sx;
    private Location dx;
    private IdList idl;
    private ExprList e;

    public AssignStat(Location sx, Location dx, IdList idl, ExprList e) {
        this.sx = sx;
        this.dx = dx;
        this.idl = idl;
        this.e = e;
    }

    public Location getSx() {
        return sx;
    }

    public void setSx(Location sx) {
        this.sx = sx;
    }

    public Location getDx() {
        return dx;
    }

    public void setDx(Location dx) {
        this.dx = dx;
    }

    public IdList getIdl() {
        return idl;
    }

    public void setIdl(IdList idl) {
        this.idl = idl;
    }

    public ExprList getE() {
        return e;
    }

    public void setE(ExprList e) {
        this.e = e;
    }

    public Object accept (Visitor v) {
        return v.visit(this);
    }
}
