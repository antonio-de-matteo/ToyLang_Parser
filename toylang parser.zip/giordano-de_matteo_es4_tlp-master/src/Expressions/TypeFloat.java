package Expressions;

import Visitor.Visitor;
import java_cup.runtime.ComplexSymbolFactory.Location;


public class TypeFloat extends Type{

    private String s;

    public TypeFloat(Location sx, Location dx, String s) {
        super(sx, dx, s);
        this.s = s;
    }

    @Override
    public String getS() {
        return s;
    }

    @Override
    public void setS(String s) {
        this.s = s;
    }
    public Object accept (Visitor v) {
        return v.visit(this);
    }
}
