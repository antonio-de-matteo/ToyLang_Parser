package Expressions;

import Visitor.Visitor;
import java_cup.runtime.ComplexSymbolFactory.Location;

public class ExprTrue extends Expr{

    public ExprTrue(Location sx,Location dx)
    {
        super(sx,dx,true);
    }
    public Object accept (Visitor v) {
        return v.visit(this);
    }
}
