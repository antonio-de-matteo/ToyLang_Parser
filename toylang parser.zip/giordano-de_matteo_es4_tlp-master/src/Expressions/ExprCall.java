package Expressions;

import Visitor.Visitor;
import java_cup.runtime.ComplexSymbolFactory.Location;

public class ExprCall extends Expr {

    private CallProc c;

    public ExprCall(Location sx, Location dx, CallProc c) {
        super(sx, dx);
        this.c = c;
    }

    public CallProc getC() {
        return c;
    }

    public void setC(CallProc c) {
        this.c = c;
    }

    public Object accept (Visitor v) {
        return v.visit(this);
    }
}
