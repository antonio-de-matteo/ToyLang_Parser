package Expressions;

import Visitor.Visitor;
import java_cup.runtime.ComplexSymbolFactory.Location;


public class StatIf extends Stat {

    private IfStat s;

    public StatIf(Location sx, Location dx,IfStat s) {
        super(sx, dx);
        this.s = s;
    }

    public IfStat getS() {
        return s;
    }

    public void setS(IfStat s) {
        this.s = s;
    }
    public Object accept (Visitor v) {
        return v.visit(this);
    }
}
