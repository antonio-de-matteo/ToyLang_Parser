package Expressions;

import Visitor.Visitor;
import java_cup.runtime.ComplexSymbolFactory;

public class ExprFalse extends Expr {
    public ExprFalse(ComplexSymbolFactory.Location sx, ComplexSymbolFactory.Location dx)
    {
        super(sx,dx,false);
    }
    public Object accept (Visitor v) {
        return v.visit(this);
    }
}
