package Visitor;


import Expressions.*;

public interface VisitorInterface {

    //Expressions
    Object visit (AssignStat ex);
    Object visit (CallProc ex);
    Object visit (Elif ex);
    Object visit (ElifList ex);
    Object visit (Else ex);
    Object visit (Expr ex);
    Object visit (ExprAnd ex);
    Object visit (ExprCall ex);
    Object visit (ExprDiv ex);
    Object visit (ExprEq ex);
    Object visit (ExprFalse ex);
    Object visit (ExprFloatConst ex);
    Object visit (ExprGe ex);
    Object visit (ExprGt ex);
    Object visit (ExprId ex);
    Object visit (ExprIntConst ex);
    Object visit (ExprLe ex);
    Object visit (ExprList ex);
    Object visit (ExprLt ex);
    Object visit (ExprMinus ex);
    Object visit (ExprMinusUn ex);
    Object visit (ExprNe ex);
    Object visit (ExprNot ex);
    Object visit (ExprNull ex);
    Object visit (ExprOr ex);
    Object visit (ExprPlus ex);
    Object visit (ExprStringConst ex);
    Object visit (ExprTimes ex);
    Object visit (ExprTrue ex);
    Object visit (IdList ex);
    Object visit (IdListInit ex);
    Object visit (IfStat ex);
    Object visit (ParamDeclList ex);
    Object visit (ParDecl ex);
    Object visit (Proc ex);
    Object visit (ProcList ex);
    Object visit (Program ex);
    Object visit (ReadlnStat ex);
    Object visit (ResultType ex);
    Object visit (ResultTypeList ex);
    Object visit (ReturnExprs ex);
    Object visit (Stat ex);
    Object visit (StatAssign ex);
    Object visit (StatCallProc ex);
    Object visit (StatIf ex);
    Object visit (StatList ex);
    Object visit (StatReadln ex);
    Object visit (StatWhile ex);
    Object visit (StatWrite ex);
    Object visit (Type ex);
    Object visit (TypeBool ex);
    Object visit (TypeFloat ex);
    Object visit (TypeInt ex);
    Object visit (TypeString ex);
    Object visit (VarDecl ex);
    Object visit (VarDeclList ex);
    Object visit (WhileStat ex);
    Object visit (WriteStat ex);




}
